﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        public void frmLogin()
        {
            Form frm = new frmLogin();
            frm.ShowDialog();

        }
        /*
        public void xemdanhmuc(int intDanhMuc)
        {
            Form frm = new frmXemDanhMuc();
            frm.Text = intDanhMuc.ToString();
            frm.ShowDialog();
        }*/
        private void frmMain_Load(object sender, EventArgs e)
        {
            frmLogin();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLogin();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult answer;
            answer = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes) Application.Exit();
        }

        private void show_panel(Form form)
        {
            
            this.pContainer.Controls.Clear();
            this.pContainer.Visible = true;
            form.Dock = DockStyle.Fill;
            form.TopLevel = false;
            form.TopMost = true;
            form.FormBorderStyle = FormBorderStyle.None;
            this.pContainer.Controls.Add(form);
            form.Show();


        }
        private void importToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Import();
            show_panel(f);

        }

        private void exportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Export();
            show_panel(f);
        }

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Report();
            show_panel(f);
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.pContainer.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void agentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Agents();
            show_panel(f);
        }

        private void ordersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Orders();
            show_panel(f);
        }

        private void storeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Store();
            show_panel(f);
        }
    }
}
