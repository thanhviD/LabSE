﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
    public partial class Export : Form
    {
        String strConn = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        public Export()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if (index < 0 || index >= dataGridView1.RowCount)
                return;
            try
            {
                DataGridViewRow row = dataGridView1.Rows[index];



                txtExportID.Text = row.Cells[0].Value.ToString();
                txtEmployeeID.Text = row.Cells[1].Value.ToString();
                txtEmployeeName.Text = row.Cells[2].Value.ToString();
                txtQuantity.Text = row.Cells[3].Value.ToString();
                dateTimeDateExport.Text = row.Cells[4].Value.ToString();
                txtItemID.Text = row.Cells[5].Value.ToString();
                txtItemName.Text = row.Cells[6].Value.ToString();

            }
            catch (Exception ex)
            {
                throw new Exception("Error:" + ex.Message);
            }
        }

        private void Export_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(Program.strConn);
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM  Export_Products ", conn);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            adapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;

            }
            else
            {
                MessageBox.Show("No data");
            }
            adapter.Dispose();
        }

        
        

        private void lblExport_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(Program.strConn);
            conn.Open();
            String sSQL = "DELETE FROM Export_Products WHERE Export_ID = '" + txtExportID.Text + "'";
            SqlCommand cmd = new SqlCommand(sSQL, conn);



            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Error:" + ex.Message);

            }
            MessageBox.Show("Edit successfully!");
            dataGridView1.Refresh();
        }

        private void btnEdit_Click_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(Program.strConn);
            conn.Open();
            String sSQL = "UPDATE Export_Products SET Export_ID = '" + txtExportID.Text + "', Employee_ID = '" + txtEmployeeID.Text + "', Employee_Name = '" + txtEmployeeName.Text + "', Quantity = '" + txtQuantity.Text + "', DateExport = '" + dateTimeDateExport.Text + "', Item_ID = '" + txtItemID.Text + "', Item_Name = '" + txtItemName.Text + "' WHERE Export_ID = '" + txtExportID.Text + "'";
            SqlCommand cmd = new SqlCommand(sSQL, conn);


            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Error:" + ex.Message);

            }
            MessageBox.Show("Edit successfully!");
            dataGridView1.Refresh();
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(Program.strConn);
            conn.Open();
            String sSQL = "INSERT INTO Export_Products VALUES ('" + txtExportID.Text + "', '" + txtEmployeeID.Text + "', '" + txtEmployeeName.Text + "', '" + txtQuantity.Text + "', '" + dateTimeDateExport.Text + "', '" + txtItemID.Text + "', '" + txtItemName.Text + "')";
            SqlCommand cmd = new SqlCommand(sSQL, conn);



            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Error:" + ex.Message);

            }
            MessageBox.Show("Edit successfully!");
            dataGridView1.Refresh();
        }
    }
}
