
use [Supplement Facts Products]

CREATE TABLE Agents(
	Agent_ID nvarchar(50) PRIMARY KEY,
	Agent_Name nvarchar(50),
	Address nvarchar(255)
	
);
CREATE TABLE Employees(
	Employee_ID nvarchar(50) PRIMARY KEY,
	Employee_Name nvarchar(255),
	Address nvarchar(255)
);

CREATE TABLE Import_Products(
	Import_ID nvarchar(50) PRIMARY KEY,
	Employee_ID nvarchar(50),
	Employee_Name nvarchar(255),
	Quantity nvarchar(50),
	DateImport nvarchar(50),
	Item_ID nvarchar(50),
	Item_Name nvarchar(255)
);

CREATE TABLE Export_Products(
	Export_ID nvarchar(50) PRIMARY KEY,
	Employee_ID nvarchar(50),
	Employee_Name nvarchar(255),
	Quantity nvarchar(50),
	DateExport nvarchar(50),
	Item_ID nvarchar(50),
	Item_Name nvarchar(255)
);

CREATE TABLE Item_Order(
    Order_ID nvarchar(50) PRIMARY KEY,
	Employee_ID nvarchar(50),
	Employee_Name nvarchar(255),
    Agent_ID nvarchar(50),
	Agent_Name nvarchar(50),
    Payment nvarchar(50),
    Quantity nvarchar(50),
    Item_ID nvarchar(50),
	Item_Name nvarchar(255)
);

CREATE TABLE Store(
	Item_ID nvarchar(50) PRIMARY KEY,
	Item_Name nvarchar(255),
	Item_Price nvarchar(50),
	Quantity nvarchar(50)
	
);

ALTER TABLE Import_Products
ADD FOREIGN KEY (Employee_ID) REFERENCES Employees(Employee_ID);

ALTER TABLE Export_Products
ADD FOREIGN KEY (Employee_ID) REFERENCES Employees(Employee_ID);

ALTER TABLE Item_Order
ADD FOREIGN KEY (Employee_ID) REFERENCES Employees(Employee_ID);
ALTER TABLE Item_Order
ADD FOREIGN KEY (Agent_ID) REFERENCES Agents(Agent_ID);
ALTER TABLE Item_Order
ADD FOREIGN KEY (Item_ID) REFERENCES Store(Item_ID);

GO

INSERT INTO Agents(Agent_ID, Agent_Name, Address) VALUES ('A001', 'Bo Sua Mall', '12A Tran Quoc Toan')
INSERT INTO Agents(Agent_ID, Agent_Name, Address) VALUES ('A002', 'Bo Sua Long Thanh', '25 Ngo Tat To')
INSERT INTO Agents(Agent_ID, Agent_Name, Address) VALUES ('A003', 'Ministop', '75/5 Tran Van Kiet')
INSERT INTO Agents(Agent_ID, Agent_Name, Address) VALUES ('A004', 'Family Mart', '60/2 Pham Huu Lau')
INSERT INTO Agents(Agent_ID, Agent_Name, Address) VALUES ('A005', 'Q Store', '30/4 Hoang Quoc Viet')
INSERT INTO Agents(Agent_ID, Agent_Name, Address) VALUES ('A006', 'Dong Nai Store', '65 Pham Ngoc Thach')
INSERT INTO Agents(Agent_ID, Agent_Name, Address) VALUES ('A007', 'Circle K', '95A Nguyen Duy Duong')


INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E001', 'Lieu Dang Khoa', '387 Pham Huu Lau')
INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E002', 'Vi Nguyen Thanh Dat', '89 Nguyen Thai Hoc')
INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E003', 'Tran Van Toan', '26 Nguyen Thong')
INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E004', 'Luu Thi Cam', '126 Nguyen Trung Truc')
INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E005', 'Nguyen Manh Tu', '307 Lanh Binh Thang')
INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E006', 'Tran Van Tai', '360 Giai Phong Street')
INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E007', 'Do Van Kiet', '135 Tran Thai Tong')
INSERT INTO Employees(Employee_ID, Employee_Name, Address) VALUES ('E008', 'Tran Ngoc Anh', '222 Le Duan')

INSERT INTO Store(Item_ID,Item_Name,Item_Price,Quantity) VALUES ('P001', 'MultiVitamine', '50.000', '500')
INSERT INTO Store(Item_ID,Item_Name,Item_Price,Quantity) VALUES ('P002', 'Thorne', '40.000', '400')
INSERT INTO Store(Item_ID,Item_Name,Item_Price,Quantity) VALUES ('P003', 'Ritual', '90.000', '90')
INSERT INTO Store(Item_ID,Item_Name,Item_Price,Quantity) VALUES ('P004', 'NaturalS', '70.000', '300')
INSERT INTO Store(Item_ID,Item_Name,Item_Price,Quantity) VALUES ('P005', 'X Nutrition', '30.000', '150')
INSERT INTO Store(Item_ID,Item_Name,Item_Price,Quantity) VALUES ('P006', 'Life Garden', '15.000', '100')
INSERT INTO Store(Item_ID,Item_Name,Item_Price,Quantity) VALUES ('P007', 'PowerUp', '20.000', '200')

/*Year-Month-Day
  A001: Agent
  E001: Employee
  P001: Product
  I001: Import
  Order001: Order
*/

INSERT INTO Import_Products(Import_ID, Employee_ID, Employee_Name, Quantity, DateImport, Item_ID,Item_Name) VALUES ('I001', 'E005', 'Nguyen Manh Tu', '100', '2022-02-15', 'P001', 'MultiVitamine')
INSERT INTO Import_Products(Import_ID, Employee_ID, Employee_Name, Quantity, DateImport, Item_ID,Item_Name) VALUES ('I002', 'E003', 'Tran Van Toan', '200', '2022-03-16', 'P002', 'Thorne')
INSERT INTO Import_Products(Import_ID, Employee_ID, Employee_Name, Quantity, DateImport, Item_ID,Item_Name) VALUES ('I003', 'E005', 'Nguyen Manh Tu', '80', '2022-01-14', 'P003', 'Ritual')
INSERT INTO Import_Products(Import_ID, Employee_ID, Employee_Name, Quantity, DateImport, Item_ID,Item_Name) VALUES ('I004', 'E002', 'Vi Nguyen Thanh Dat', '30', '2022-01-02', 'P004', 'NaturalS')
INSERT INTO Import_Products(Import_ID, Employee_ID, Employee_Name, Quantity, DateImport, Item_ID,Item_Name) VALUES ('I005', 'E001', 'Lieu Dang Khoa', '50', '2022-03-20', 'P005', 'X Nutrition')
INSERT INTO Import_Products(Import_ID, Employee_ID, Employee_Name, Quantity, DateImport, Item_ID,Item_Name) VALUES ('I006', 'E004', 'Luu Thi Cam', '70', '2022-05-15', 'P006', 'Life Garden')
INSERT INTO Import_Products(Import_ID, Employee_ID, Employee_Name, Quantity, DateImport, Item_ID,Item_Name) VALUES ('I007', 'E006', 'Tran Van Tai', '70', '2022-05-20', 'P007', 'PowerUp')

INSERT INTO Item_Order(Order_ID,Employee_ID,Employee_Name,Agent_ID,Agent_Name,Payment,Quantity,Item_ID,Item_Name) VALUES ('Order001', 'E003', 'Tran Van Toan', 'A001', 'Bo Sua Mall', 'Cash', '45', 'P006', 'Life Garden')
INSERT INTO Item_Order(Order_ID,Employee_ID,Employee_Name,Agent_ID,Agent_Name,Payment,Quantity,Item_ID,Item_Name) VALUES ('Order002', 'E002', 'Vi Nguyen Thanh Dat', 'A002', 'Bo Sua Long Thanh', 'Cash', '60', 'P003', 'Ritual')
INSERT INTO Item_Order(Order_ID,Employee_ID,Employee_Name,Agent_ID,Agent_Name,Payment,Quantity,Item_ID,Item_Name) VALUES ('Order003', 'E007', 'Do Van Kiet', 'A003', 'Ministop', 'Credit Card', '200', 'P001', 'MultiVitamine')
INSERT INTO Item_Order(Order_ID,Employee_ID,Employee_Name,Agent_ID,Agent_Name,Payment,Quantity,Item_ID,Item_Name) VALUES ('Order004', 'E005', 'Nguyen Manh Tu', 'A004', 'Family Mart', 'Banking', '70', 'P005', 'X Nutrition')
INSERT INTO Item_Order(Order_ID,Employee_ID,Employee_Name,Agent_ID,Agent_Name,Payment,Quantity,Item_ID,Item_Name) VALUES ('Order005', 'E004', 'Luu Thi Cam', 'A005', 'Q Store', 'Cash', '100', 'P002', 'Thorne')
INSERT INTO Item_Order(Order_ID,Employee_ID,Employee_Name,Agent_ID,Agent_Name,Payment,Quantity,Item_ID,Item_Name) VALUES ('Order006', 'E006', 'Tran Van Tai', 'A006', 'Dong Nai Store', 'Cash', '150', 'P004', 'NaturalS')                    
INSERT INTO Item_Order(Order_ID,Employee_ID,Employee_Name,Agent_ID,Agent_Name,Payment,Quantity,Item_ID,Item_Name) VALUES ('Order007', 'E008', 'Tran Ngoc Anh', 'A007', 'Circle K', 'Banking', '100', 'P007', 'PowerUp')                    


INSERT INTO Export_Products(Export_ID, Employee_ID, Employee_Name, Quantity, DateExport, Item_ID,Item_Name) VALUES ('EX001', 'E007', 'Do Van Kiet', '200', '2022-06-15', 'P001', 'MultiVitamine')
INSERT INTO Export_Products(Export_ID, Employee_ID, Employee_Name, Quantity, DateExport, Item_ID,Item_Name) VALUES ('EX002', 'E006', 'Tran Van Tai', '150', '2022-06-15', 'P004', 'NaturalS')
INSERT INTO Export_Products(Export_ID, Employee_ID, Employee_Name, Quantity, DateExport, Item_ID,Item_Name) VALUES ('EX003', 'E005', 'Nguyen Manh Tu', '70', '2022-07-15', 'P005', 'X Nutrition')
INSERT INTO Export_Products(Export_ID, Employee_ID, Employee_Name, Quantity, DateExport, Item_ID,Item_Name) VALUES ('EX004', 'E004', 'Luu Thi Cam', '100', '2022-08-15', 'P002', 'Thorne')
INSERT INTO Export_Products(Export_ID, Employee_ID, Employee_Name, Quantity, DateExport, Item_ID,Item_Name) VALUES ('EX005', 'E003', 'Tran Van Toan', '45', '2022-09-15', 'P006', 'Life Garden')
INSERT INTO Export_Products(Export_ID, Employee_ID, Employee_Name, Quantity, DateExport, Item_ID,Item_Name) VALUES ('EX006', 'E002', 'Vi Nguyen Thanh Dat', '60', '2022-10-15', 'P003', 'Ritual')
INSERT INTO Export_Products(Export_ID, Employee_ID, Employee_Name, Quantity, DateExport, Item_ID,Item_Name) VALUES ('EX007', 'E008', 'Tran Ngoc Anh', '100', '2022-10-20', 'P007', 'PowerUp')






