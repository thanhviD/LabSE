This is an instruction for running the projects.
The SE package has two projects, one for C# Forms and one for Web MVC and a sql script database.sql

C# Forms:
	- Open database.sql to get data
	- Run Final.sln
	- In App.config change connection string to desired path and database
	- Press Start to run 

Web MVC:
	- Open database.sql to get data
	- Run Website.sln
	- In App.config change connection string to desired path and database
	- Press Start to run 
